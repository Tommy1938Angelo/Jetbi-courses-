/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblesson/WorklistApp/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblesson/WorklistApp/test/integration/pages/Worklist",
	"zjblesson/WorklistApp/test/integration/pages/Object",
	"zjblesson/WorklistApp/test/integration/pages/NotFound",
	"zjblesson/WorklistApp/test/integration/pages/Browser",
	"zjblesson/WorklistApp/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblesson.WorklistApp.view."
	});

	sap.ui.require([
		"zjblesson/WorklistApp/test/integration/WorklistJourney",
		"zjblesson/WorklistApp/test/integration/ObjectJourney",
		"zjblesson/WorklistApp/test/integration/NavigationJourney",
		"zjblesson/WorklistApp/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});
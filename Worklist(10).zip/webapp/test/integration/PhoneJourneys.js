/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"Worklist/Worklist/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"Worklist/Worklist/test/integration/pages/App",
	"Worklist/Worklist/test/integration/pages/Browser",
	"Worklist/Worklist/test/integration/pages/Master",
	"Worklist/Worklist/test/integration/pages/Detail",
	"Worklist/Worklist/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "Worklist.Worklist.view."
	});

	sap.ui.require([
		"Worklist/Worklist/test/integration/NavigationJourneyPhone",
		"Worklist/Worklist/test/integration/NotFoundJourneyPhone",
		"Worklist/Worklist/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});
/*global location*/
sap.ui.define([
	"zjblesson/WorklistApp/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"zjblesson/WorklistApp/model/formatter",
	"sap/m/MessageToast",
	"sap/m/MessageBox"

], function(
	BaseController,
	JSONModel,
	History,
	formatter,
	MessageToast,
	MessageBox
) {
	"use strict";

	return BaseController.extend("zjblesson.WorklistApp.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0,
					editMode: false,
					newMaterial: null
				});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		setJSONModel: function(sMaterialID) {
			this.getModel().read("/zjblessons_base_Materials('" + sMaterialID + "')", {
				success: function(oData) {
					this.setModel(new JSONModel({}), "json");
					this.getModel("json").setData(oData);
					this.getModel("objectView").setProperty("/cancelMaterial", Object.assign({}, oData));

				}.bind(this),
				error: function() {
					MessageToast.show(this.getResourceBundle().getText("Error"));
				}
			});
		},
		
		onEditToggled: function(oEvent) {
			if (!oEvent.getParameter("editable")) {

				var bHasPendingChanges = this.getModel().hasPendingChanges();
				if (!bHasPendingChanges) {
					return;
				}
				//this.saveObject();
				var sMessageBoxText = this.getResourceBundle().getText("Doyouwanttosavechanges");
				var sMessageBoxOnOkText = this.getResourceBundle().getText("Ok");
				var sMessageBoxOnCloseText = this.getResourceBundle().getText("Close");
				MessageBox.confirm(sMessageBoxText, {
					actions: [sMessageBoxOnOkText, sMessageBoxOnCloseText],
					emphasizedAction: sMessageBoxOnOkText,
					onClose: function(sAction) {
						if (sAction === sMessageBoxOnOkText) {
							this.saveObject();
						} else {
							this.cancelObject();
						}
					}.bind(this)
				});
			}
		},
		
		
		/*
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onPressChange: function(oEvent) {
			var bChangeState = oEvent.getSource().getState();
			this.getModel("objectView").setProperty("/enableChange", bChangeState);
		},
		onPressReset: function(oEvent) {
			this.getModel().resetChanges();
			MessageToast.show("Reset");
		},
		onPressRefresh: function(oEvent) {
			this.getModel().refresh();
			MessageToast.show("Refreshed");
		},

		onPressEdit: function() {
			this.getModel("objectView").setProperty("/editMode", true);
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
		
		
		
		
		onTabSelect: function(oEvent) {
			var oTabBar = this.byId("idIconTabBarStretchContent");
			var editMode = this.getModel("objectView").getProperty("/editMode");
			var previousKey = oEvent.getParameter("previousKey");
			if (editMode) {
				oTabBar.setSelectedKey(previousKey);
			}
		},
		
		
		onChangeRegionText: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			MessageToast.show(sValue);
		},
		
		
		saveObject: function() {
			this.getModel("objectView").setProperty("/editMode", false);
			this.getModel().submitChanges({
				success: function() {
					var MessageSuccess = this.getResourceBundle().getText("Success");
					MessageToast.show(MessageSuccess);
				}.bind(this),
				error: function() {
					var MessageError = this.getResourceBundle().getText("Error");
					MessageToast.show(MessageError);
				}.bind(this)
			});
		},
		
		

		onPressAccept: function(oEvent) {
			MessageToast.show("Saved");
			var sPath = this.getView().getBindingContext().getPath() + "/";
			var sMaterialText = this.getView().byId("InputMaterialText").getValue();
			var iSubGroupID = this.getView().byId("successSelect").getSelectedIndex() + 1;
			var iGroupID = this.getView().byId("btnGroup").getSelectedIndex() + 1;
			var sIntegrationID = this.getView().byId("InputIntegrationID").getValue();
			this.getModel().setProperty(sPath + "MaterialText", sMaterialText);
			this.getModel().setProperty(sPath + "SubGroupID", iSubGroupID.toString());
			this.getModel().setProperty(sPath + "GroupID", iGroupID.toString());
			this.getModel().setProperty(sPath + "IntegrationID", sIntegrationID);
			this.getModel().submitChanges();

		},
		
		
		cancelObject: function() {
			this.getModel().resetChanges();
		},


		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;

			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("zjblessons_base_Materials", {
					MaterialID: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		onPressBack: function() {
			this.getRouter().navTo("worklist");
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */

		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		onPressSave: function() {
			this.getModel("objectView").setProperty("/editMode", false);
			var oSaveMaterial = this.getModel("json").getProperty("/");
			this.getModel("objectView").setProperty("/cancelMaterial", Object.assign({}, oSaveMaterial));
			var sPath = this.getModel().createKey("/zjblessons_base_Materials", {
				MaterialID: oSaveMaterial.MaterialID
			});
			this.getModel().update(sPath, {
				MaterialText: oSaveMaterial.MaterialText,
				GroupID: oSaveMaterial.GroupID,
				SubGroupID: oSaveMaterial.SubGroupID,
				MaterialDescription: oSaveMaterial.MaterialDescription
			}, {
				success: function() {
					var MessageSuccess = this.getResourceBundle().getText("Success");
					MessageToast.show(MessageSuccess);
				}.bind(this),
				error: function() {
					var MessageError = this.getResourceBundle().getText("Error");
					MessageToast.show(MessageError);
				}.bind(this)
			});
		},

		onPressCancel: function() {
			this.getModel("objectView").setProperty("/editMode", false);
			var oCancelMaterial = this.getModel("objectView").getProperty("/cancelMaterial");
			this.getModel("json").setData(oCancelMaterial);
		},

		

			

		/*	onChangeMessageToast: function(oEvent) {
				var oSmartField = oEvent.getSource();
				var oSmartFieldSelect = oSmartField.getValue();

				MessageToast.show('${this.getModel("i18n").getResourceBundle().getText("tselectField")} ${oSmartFieldSelect}');
			},*/

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.MaterialID,
				sObjectName = oObject.MaterialText;

			oViewModel.setProperty("/busy", false);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		}

	});

});
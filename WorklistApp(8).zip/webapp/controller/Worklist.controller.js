/*global location history */
sap.ui.define([
	"zjblesson/WorklistApp/controller/BaseController",
	"sap/ui/model/json/JSONModel",

	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/MessageBox"

], function(BaseController, JSONModel, Filter, FilterOperator, MessageToast, Dialog, MessageBox) {
	"use strict";

	return BaseController.extend("zjblesson.WorklistApp.controller.Worklist", {

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._aTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		onPressSayHello: function() {
			var sMessageText = this.getResourceBundle().getText("HelloWorldMessageToastText");
			MessageToast.show(sMessageText);
		},
		onPressReset: function() {
			this.getModel().resetChanges();
		},

		onPressSubmit: function() {
			this.getModel().submitChanges();
		},

		_createMaterial: function() {
			var oEntry = {
				MaterialID: "",
				MaterialText: this.oDialogCreate.getContent()[1].getValue(),
				Language: "RU",
				GroupID: this.oDialogCreate.getContent()[3].getValue(),
				Version: "A",
				SubGroupID: this.oDialogCreate.getContent()[5].getValue()
			};
			this.getModel().create("/zjblessons_base_Materials", oEntry, {
				sucess: function(e) {
					MessageToast.show("New Material was created successfully");
				},
				error: function(e) {
					MessageToast.show("Error");
				}
			});
			this.oDialogCreate.getContent()[1].setValue("");
			this.oDialogCreate.getContent()[3].setValue("");
			this.oDialogCreate.getContent()[5].setValue("");

		},

		setCreateEnabled: function() {
			var isEnabled = (
				this.oDialogCreate.getContent()[1].getValue() !== "" &&
				this.oDialogCreate.getContent()[3].getValue() !== "" &&
				this.oDialogCreate.getContent()[5].getValue() !== ""
			);
			this.oDialogCreate.getModel("dialog").setProperty("/beginButtonEnabled", isEnabled);
		},

		// setUpdateVisible: function() {
		// 	var Visible = this.getView().byId("btn1");
		// 	if (Visible.getVisible()) {
		// 		Visible.setVisible(false);
		// 	}
		// },

		openEditMaterialDialog: function(oSource) {
			if (!this.oEditMaterialDialog) {

				this.oEditMaterialDialog = new Dialog({
					title: "{i18n>UpdateMaterial}",
					type: "Message",
					contentwidth: "24em",
					content: [
						new sap.m.Label({
							text: "{i18n>MaterialText}",
							labelFor: "MaterialTextCreate"
						}),
						new sap.m.Input("MaterialTextEdit", {
							width: "100%",
							maxLength: 20,
							value: "{MaterialText}",
							liveChange: this.onEditMaterialDialogInputChanged.bind(this)
						}),
						new sap.m.Label({
							text: "{i18n>GroupID}",
							labelFor: "GroupCreate"
						}),
						new sap.m.Input("GroupEdit", {
							width: "100%",
							maxLength: 10,
							value: "{GroupID}",
							liveChange: this.onEditMaterialDialogInputChanged.bind(this)
						})
					],
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: "{i18n>Update}",
						enabled: "{editDialogModel>/editButtonEnabled}",
						press: function() {
							this.oEditMaterialDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "{i18n>Reset}",
						press: function(oEvent) {
							var oBidningContext = oEvent.getSource().getBindingContext();
							this.getModel().resetChanges([oBidningContext.getPath()]);
							this.oEditMaterialDialog.close();
						}.bind(this)
					})
				}).addStyleClass("sapUiSizeCompact");

				this.oEditMaterialDialog.setModel(new JSONModel(), "editDialogModel");
				this.getView().addDependent(this.oEditMaterialDialog);
			}

			this.oEditMaterialDialog.getModel("editDialogModel").setData({
				editButtonEnabled: true
			});

			this.oEditMaterialDialog.setBindingContext(oSource.getBindingContext());
			this.oEditMaterialDialog.open();
		},

		openCreateMaterialDialog: function() {
			if (!this.oCreateMaterialDialog) {

				this.oCreateMaterialDialog = new Dialog({
					id: "CreateMaterialDialog",
					title: "{i18n>CreatenewMaterial}",
					type: "Message",
					contentwidth: "24em",
					content: [
						new sap.m.Label({
							text: "{i18n>MaterialText}",
							labelFor: "MaterialTextCreate"
						}),
						new sap.m.Input("MaterialTextCreate", {
							width: "100%",
							maxLength: 20,
							value: "{createDialogModel>/materialText}",
							liveChange: this.onCreateMaterialDialogInputChanged.bind(this)
						}),
						new sap.m.Label({
							text: "{i18n>GroupID}",
							labelFor: "GroupCreate"
						}),
						new sap.m.Input("GroupCreate", {
							width: "100%",
							maxLength: 10,
							value: "{createDialogModel>/groupID}",
							liveChange: this.onCreateMaterialDialogInputChanged.bind(this)
						})
					],
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: "{i18n>Create}",
						enabled: "{createDialogModel>/createButtonEnabled}",
						press: function() {
							this._createMaterial();

							this.oCreateMaterialDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "{i18n>Cancel}",
						press: function() {
							this.oCreateMaterialDialog.close();
						}.bind(this)
					})

				}).addStyleClass("sapUiSizeCompact");

				this.oCreateMaterialDialog.setModel(new JSONModel(), "createDialogModel");
				this.getView().addDependent(this.oCreateMaterialDialog);
			}

			this.oCreateMaterialDialog.getModel("createDialogModel").setData({
				groupID: "",
				materialText: "",
				createButtonEnabled: false
			});

			this.oCreateMaterialDialog.open();
		},

		onEditMaterialDialogInputChanged: function(oEvent) {
			var sMaterialText = this.oEditMaterialDialog.getContent()[1].getValue();
			var sGroupId = this.oEditMaterialDialog.getContent()[3].getValue();

			var bEditButtonEnabled = !!sMaterialText.trim() && !!sGroupId.trim();

			this.oEditMaterialDialog.getModel("editDialogModel").setProperty("/editButtonEnabled", bEditButtonEnabled);
		},

		onCreateMaterialDialogInputChanged: function(oEvent) {
			var oDialogModel = this.oCreateMaterialDialog.getModel("createDialogModel");
			var sMaterialText = this.oCreateMaterialDialog.getContent()[1].getValue();
			var sGroupId = this.oCreateMaterialDialog.getContent()[3].getValue();

			var bCreateButtonEnabled = !!sMaterialText.trim() && !!sGroupId.trim();

			oDialogModel.setProperty("/createButtonEnabled", bCreateButtonEnabled);
		},

		_updateMaterial: function() {
			var sPath = this.oDialogUpdate.getBindingContext().getPath();
			this.getModel().update(sPath, {
				MaterialText: this.oDialogUpdate.getContent()[1].getValue(),
				GroupID: this.oDialogUpdate.getContent()[3].getValue(),
				SubGroupID: this.oDialogUpdate.getContent()[5].getValue()
			}, {
				success: function(e) {
					MessageToast.show("Material was updated successfully");
				},
				error: function(e) {
					MessageToast.show("Error");
				}
			});
			this.oDialogUpdate.getContent()[1].setValue("");
			this.oDialogUpdate.getContent()[3].setValue("");
			this.oDialogUpdate.getContent()[5].setValue("");
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearchSubGroupText: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("SubGroupText", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		onSearchMaterialText: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("MaterialText", FilterOperator.EQ, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("MaterialText", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */

		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		onPressRefresh: function() {
			this.getView().getModel().refresh(true);
			MessageToast.show("Success refresh");
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */

		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("MaterialID")
			});
		},

		OnPressCreate: function(oEvent) {
			var that = this;
			var oDialog = new Dialog({
				title: "New Item",
				type: "Message",
				content: [
					new sap.m.Label({
						text: "Write Material Text",
						labelFor: "MaterialTextCreate"
					}),
					new sap.m.Input("MaterialTextCreate", {
						width: "100%",
						placeholder: "",
						maxLength: 20,
						liveChange: function(oEvent) {
							var sTextMaterialText = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sTextMaterialText.split(" ").join("").length > 0);
						}
					}),

					new sap.m.Label({
						text: "Write Group ID",
						labelFor: "GroupIDCreate"
					}),
					new sap.m.Input("GroupIDCreate", {
						width: "100%",
						placeholder: "From 1 to 5",
						maxLength: 1,
						liveChange: function(oEvent) {
							var sTextGroupID = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sTextGroupID.split(" ").join("").length === 1);
						}
					}),
					new sap.m.Label({
						text: "Write SubGroup ID",
						labelFor: "SubGroupIDCreate"
					}),
					new sap.m.Input("SubGroupIDCreate", {
						width: "100%",
						placeholder: "From 1 to 6",
						maxLength: 1,
						liveChange: function(oEvent) {
							var sTextSubGroupID = oEvent.getParameter("value");
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sTextSubGroupID.split(" ").join("").length === 1);
						}
					})
				],
				beginButton: new sap.m.Button({
					type: "Emphasized",
					text: "Create",
					enabled: false,
					press: function() {
						oDialog.close();
						var oEntry = {
							MaterialID: "",
							MaterialText: oDialog.getContent()[1].getValue(),
							Language: "RU",
							GroupID: oDialog.getContent()[3].getValue(),
							SubGroupID: oDialog.getContent()[5].getValue(),
							Version: "A"
						};
						that.getModel().create("/zjblessons_base_Materials", oEntry, {
							success: function() {
								MessageToast.show("Successfully created new Material.");
							},
							error: function() {
								MessageToast.show("Error!");
							}
						});
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function() {
						oDialog.close();
					}
				}),
				afterClose: function() {
					oDialog.destroy();
				}
			});
			oDialog.open();
		},

		onPressDelete: function(oEvent) {
			if (this.getView().byId("table").getSelectedItems().length === 0) {
				MessageToast.show("Select Item!");
			} else {
				var that = this;
				var oItem = this.getView().byId("table").getSelectedItems()[0].getBindingContext().getPath();
				var oDialog = new Dialog({
					title: "Confirm delete",
					type: "Message",
					content: new sap.m.Text({
						text: "Delete?"
					}),
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: "Delete",
						press: function() {
							that.getModel().remove(oItem);
							oDialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function() {
							oDialog.close();
						}
					}),
					afterClose: function() {
						oDialog.destroy();
					}
				});
				oDialog.open();
			}
		},

		OnPressUpdate: function(oEvent) {
			if (this.getView().byId("table").getSelectedItems().length === 0) {
				MessageToast.show("Select item!");
			} else {
				var that = this;
				var oItem = this.getView().byId("table").getSelectedItems()[0].getBindingContext().getPath();
				var oDialog = new Dialog({
					title: "Write Material Text",
					type: "Message",
					content: [new sap.m.Label({
							text: "Write new Material Text",
							labelFor: "MaterialTextUpdate"
						}),
						new sap.m.Input("MaterialTextUpdate", {
							width: "100%",
							placeholder: "",
							maxLength: 20,
							liveChange: function() {
								var sText = oEvent.getParameter("value");
								var parent = oEvent.getSource().getParent();
								parent.getBeginButton().setEnabled(sText.split(" ").join("").length > 0);
							}
						}),
						new sap.m.Label({
							text: "Write new GroupID",
							labelFor: "GroupIDUpdate"
						}),
						new sap.m.Input("GroupIDUpdate", {
							width: "100%",
							placeholder: "From 1 to 5",
							maxLength: 1,
							liveChange: function() {
								var sText = oEvent.getParameter("value");
								var parent = oEvent.getSource().getParent();
								parent.getBeginButton().setEnabled(sText.split(" ").join("").length > 0);
							}
						}),
						new sap.m.Label({
							text: "Write new SubGroupID",
							labelFor: "SubGroupIDUpdate"
						}),
						new sap.m.Input("SubGroupIDUpdate", {
							width: "100%",
							placeholder: "From 1 to 6",
							maxLength: 1,
							liveChange: function() {
								var sText = oEvent.getParameter("value");
								var parent = oEvent.getSource().getParent();
								parent.getBeginButton().setEnabled(sText.split(" ").join("").length > 0);
							}
						})
					],
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: "Update",
						enabled: false,
						press: function() {
							that.getModel().update(oItem, {
								MaterialText: oDialog.getContent()[1].getValue(),
								GroupID: oDialog.getContent()[3].getValue(),
								SubGroupID: oDialog.getContent()[5].getValue()
							}, {
								success: function(e) {
									MessageToast.show("Updated.");
								},
								error: function(e) {
									MessageToast.show("Error!");
								}
							});
							oDialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function() {
							oDialog.close();
						}
					}),
					afterClose: function() {
						oDialog.destroy();
					}
				});
				oDialog.open();
			}
		},

		Select: function() {
			if (this.getView().byId("table").getSelectedItems()[0].getBindingContext().getPath().getValue() === "d1b1000043") {
				MessageToast.show("Select item!");
			} else {
				MessageToast.show("Error!");
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */

		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});
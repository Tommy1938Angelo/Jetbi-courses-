sap.ui.define([], function() {
	"use strict";

	return {
		formatHighlight: function(sCreatedBy) {
			if (sCreatedBy === "D1B1000043") {
				return "Success";
			}

			return "None";
		},

		formatEditDeleleVisible: function(sCreatedBy) {
			return sCreatedBy === "D1B1000043";
		},

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		
		formatedDateSmartField: function(Modified) {
			var dModifedDateFormated = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "YYYY.MM.dd"
			}).format(Modified);

			return dModifedDateFormated;
		}

	};

});
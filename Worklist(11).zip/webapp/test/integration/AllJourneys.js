/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 MaterialID in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"Worklist/Worklist/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"Worklist/Worklist/test/integration/pages/App",
	"Worklist/Worklist/test/integration/pages/Browser",
	"Worklist/Worklist/test/integration/pages/Master",
	"Worklist/Worklist/test/integration/pages/Detail",
	"Worklist/Worklist/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "Worklist.Worklist.view."
	});

	sap.ui.require([
		"Worklist/Worklist/test/integration/MasterJourney",
		"Worklist/Worklist/test/integration/NavigationJourney",
		"Worklist/Worklist/test/integration/NotFoundJourney",
		"Worklist/Worklist/test/integration/BusyJourney"
	], function () {
		QUnit.start();
	});
});